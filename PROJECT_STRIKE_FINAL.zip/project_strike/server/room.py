from .game_state import Room
import uuid
class RoomManager:
    def __init__(self): self.rooms={}; self.waiting={'solo':[],'duo':[],'squad':[]}
    def find_or_create(self,mode):
        for r in self.rooms.values():
            if r.mode==mode and r.phase=='waiting' and len(r.players)<r.max_players: return r
        r=Room(str(uuid.uuid4())[:8],mode); self.rooms[r.id]=r; return r
    def remove_empty(self):
        for rid in list(self.rooms):
            if not self.rooms[rid].players: self.rooms.pop(rid,None)
