import asyncio, json, math, random, time, os
from websockets.asyncio.server import serve
from .room import RoomManager
from .game_state import PlayerState

WEAPONS={
 'AR-01':dict(damage=22,rate=.105,mag=30,reload=2.1,range=180,head=1.5,pellets=1),
 'SMG-01':dict(damage=15,rate=.065,mag=35,reload=1.8,range=90,head=1.4,pellets=1),
 'SHOT-01':dict(damage=9,rate=.75,mag=6,reload=2.4,range=38,head=1.25,pellets=8),
 'DMR-01':dict(damage=42,rate=.35,mag=12,reload=2.3,range=260,head=1.65,pellets=1),
 'SNIPER-01':dict(damage=90,rate=1.3,mag=5,reload=2.8,range=500,head=2,pellets=1),
}
rooms=RoomManager(); peers={}; parties={}

def now(): return time.monotonic()
def ray_point(p,dx,dy,dist): return p.x+dx*dist,p.y+dy*dist

def hit_test(room,shooter,angle,weapon):
    w=WEAPONS[weapon]; best=None; best_t=w['range']
    sx,sy=shooter.x,shooter.y
    for p in room.living():
        if p.id==shooter.id: continue
        vx,vy=p.x-sx,p.y-sy; t=vx*math.cos(angle)+vy*math.sin(angle)
        if t<=0 or t>best_t: continue
        perp=abs(vx*math.sin(angle)-vy*math.cos(angle))
        if perp < 1.25:
            best=p; best_t=t
    return best,best_t

async def send(ws,msg):
    try: await ws.send(json.dumps(msg,separators=(',',':')))
    except: pass
async def broadcast(room,msg):
    for p in list(room.players.values()):
        ws=peers.get(p.id)
        if ws: await send(ws,msg)

async def handle(ws):
    pid=None; room=None
    try:
        async for raw in ws:
            try: m=json.loads(raw)
            except: continue
            typ=m.get('type')
            if typ=='join':
                pid=str(m.get('player_id') or os.urandom(8).hex()); mode=m.get('mode','solo')
                if mode not in ('solo','duo','squad'): mode='solo'
                room=rooms.find_or_create(mode); p=PlayerState(pid); room.add(p); peers[pid]=ws
                await send(ws,{'type':'joined','player_id':pid,'room_id':room.id,'mode':room.mode})
                await broadcast(room,{'type':'state','state':room.snapshot()})
            elif not room or not pid or pid not in room.players: continue
            elif typ=='move':
                p=room.players[pid]; nx=float(m.get('x',p.x)); ny=float(m.get('y',p.y));
                maxstep=.9 if not p.sprint else 1.35
                if math.hypot(nx-p.x,ny-p.y)<=maxstep: p.x,p.y=nx,ny
                p.yaw=float(m.get('yaw',p.yaw)); p.pitch=float(m.get('pitch',p.pitch)); p.sprint=bool(m.get('sprint',False))
            elif typ=='shoot':
                p=room.players[pid]; t=now(); w=WEAPONS.get(p.weapon)
                if not p.alive or not w or p.reloading_until>t or p.ammo<=0 or t-p.last_shot<w['rate']: continue
                p.last_shot=t; p.ammo-=1; angle=math.radians(float(m.get('yaw',p.yaw)))
                target,d=hit_test(room,p,angle,p.weapon)
                if target:
                    dmg=w['damage']*(w['pellets'] if w['pellets'] else 1)
                    dmg=min(dmg,100); armor_absorb=min(target.armor,dmg*.65); target.armor-=armor_absorb; dmg-=armor_absorb
                    target.hp-=dmg; p.damage+=round(dmg)
                    await broadcast(room,{'type':'hit','shooter':pid,'target':target.id,'damage':round(dmg),'distance':round(d,1)})
                    if target.hp<=0:
                        target.hp=0; target.alive=False; p.kills+=1; room.killfeed.append({'killer':pid,'victim':target.id,'weapon':p.weapon})
                        await broadcast(room,{'type':'elimination','killer':pid,'victim':target.id})
                        alive=room.living()
                        if len(alive)<=1 and room.phase=='active':
                            room.phase='finished'
                            if alive: room.placements[alive[0].id]=1
                            await broadcast(room,{'type':'match_end','winner':alive[0].id if alive else None,'state':room.snapshot()})
                await broadcast(room,{'type':'shot','player':pid,'yaw':p.yaw,'hit':bool(target)})
            elif typ=='reload':
                p=room.players[pid]; w=WEAPONS[p.weapon]
                if p.ammo<w['mag'] and p.reserve>0 and p.reloading_until<=now(): p.reloading_until=now()+w['reload']
            elif typ=='weapon':
                p=room.players[pid]; wid=m.get('weapon')
                if wid in p.inventory: p.weapon=wid; p.ammo=WEAPONS[wid]['mag']
            elif typ=='pickup':
                p=room.players[pid]; lid=m.get('loot_id')
                for l in room.loot:
                    if l.id==lid and not l.taken and p.dist(l.x,l.y)<4.0:
                        if l.kind=='weapon':
                            if l.item_id not in p.inventory:
                                for i in range(6):
                                    if p.inventory[i] is None: p.inventory[i]=l.item_id; break
                                else: p.inventory[0]=l.item_id
                        elif l.kind=='armor': p.armor=min(100,p.armor+50)
                        elif l.kind=='medkit': p.hp=min(100,p.hp+40)
                        elif l.kind=='ammo': p.reserve=min(300,p.reserve+60)
                        l.taken=True; await send(ws,{'type':'pickup_ok','loot_id':lid})
                        break
            elif typ=='ping': await send(ws,{'type':'pong','t':m.get('t')})
            elif typ=='party_create':
                parties[pid]={'leader':pid,'mode':m.get('mode','squad'),'members':[pid]}; await send(ws,{'type':'party','party':parties[pid]})
            elif typ=='party_invite':
                target=str(m.get('target','')); q=peers.get(target)
                if q: await send(q,{'type':'party_invite','from':pid,'mode':m.get('mode','squad')})
            elif typ=='party_join':
                leader=str(m.get('leader','')); party=parties.get(leader)
                if party and pid not in party['members'] and len(party['members'])<4: party['members'].append(pid); await broadcast(room,{'type':'party','party':party})
    except Exception as e:
        pass
    finally:
        if pid and room:
            room.remove(pid)
            peers.pop(pid,None)
            await broadcast(room,{'type':'state','state':room.snapshot()})
        rooms.remove_empty()

async def ticker():
    while True:
        await asyncio.sleep(.25)
        for room in list(rooms.rooms.values()):
            if room.phase!='active': continue
            room.match_time+=.25
            # Zone begins shrinking after 20s, then cycles toward smaller rings.
            if room.match_time>20:
                target=max(18,240-(room.match_time-20)*1.6)
                room.zone_target=target
                room.zone_radius=max(target,room.zone_radius-.12)
                for p in room.living():
                    if p.dist(room.zone_x,room.zone_y)>room.zone_radius:
                        p.hp-=2.2
                        if p.hp<=0: p.hp=0; p.alive=False; room.killfeed.append({'killer':'ZONE','victim':p.id,'weapon':'ZONE'})
            if int(room.match_time*4)%4==0:
                await broadcast(room,{'type':'state','state':room.snapshot()})

async def main():
    async with serve(handle,'0.0.0.0',8765,max_size=2**20):
        print('PROJECT: STRIKE server on ws://0.0.0.0:8765')
        await ticker()
if __name__=='__main__': asyncio.run(main())
