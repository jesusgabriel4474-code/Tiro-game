from dataclasses import dataclass, field
from time import monotonic
from math import hypot
import random, uuid

@dataclass
class PlayerState:
    id:str
    x:float=0; y:float=0; z:float=1.0; yaw:float=0; pitch:float=0
    hp:float=100; armor:float=0; alive:bool=True
    weapon:str='AR-01'; ammo:int=30; reserve:int=120; inventory:list=field(default_factory=lambda:['AR-01',None,None,None,None,None])
    kills:int=0; damage:int=0; last_shot:float=0; reloading_until:float=0; sprint:bool=False
    def dist(self,x,y): return hypot(self.x-x,self.y-y)
    def snapshot(self):
        return {'id':self.id,'x':self.x,'y':self.y,'z':self.z,'yaw':self.yaw,'pitch':self.pitch,'hp':round(self.hp,1),'armor':round(self.armor,1),'alive':self.alive,'weapon':self.weapon,'ammo':self.ammo,'reserve':self.reserve,'inventory':self.inventory,'kills':self.kills}

@dataclass
class Loot:
    id:str; kind:str; item_id:str; x:float; y:float; z:float=0.5; taken:bool=False
    def snapshot(self): return {'id':self.id,'kind':self.kind,'item_id':self.item_id,'x':self.x,'y':self.y,'z':self.z}

class Room:
    def __init__(self,rid,mode):
        self.id=rid; self.mode=mode; self.max_players={'solo':1,'duo':2,'squad':4}[mode]
        self.players={}; self.phase='waiting'; self.started=monotonic(); self.match_time=0
        self.zone_x=0; self.zone_y=0; self.zone_radius=240.0; self.zone_target=240.0; self.zone_next=240.0
        self.loot=[]; self.killfeed=[]; self.placements={}
        self._spawn_loot()
    def _spawn_loot(self):
        weapons=['AR-01','SMG-01','SHOT-01','DMR-01','SNIPER-01']
        for i in range(45):
            a=random.random()*6.283; r=(random.random()**.5)*220
            self.loot.append(Loot(str(uuid.uuid4()),'weapon',random.choice(weapons),__import__('math').cos(a)*r,__import__('math').sin(a)*r))
        for i in range(35):
            a=random.random()*6.283; r=(random.random()**.5)*220
            self.loot.append(Loot(str(uuid.uuid4()),random.choice(['armor','medkit','ammo']),random.choice(['armor','medkit','5.56','9mm','12g','7.62']),__import__('math').cos(a)*r,__import__('math').sin(a)*r))
    def add(self,p):
        if len(self.players)>=self.max_players: return False
        p.x=random.uniform(-25,25); p.y=random.uniform(-25,25); self.players[p.id]=p
        if len(self.players)==self.max_players: self.phase='active'
        return True
    def remove(self,pid): self.players.pop(pid,None)
    def living(self): return [p for p in self.players.values() if p.alive]
    def snapshot(self):
        return {'room':self.id,'mode':self.mode,'phase':self.phase,'players':[p.snapshot() for p in self.players.values()],
                'loot':[x.snapshot() for x in self.loot if not x.taken],
                'zone':{'x':self.zone_x,'y':self.zone_y,'radius':self.zone_radius,'target':self.zone_target},'killfeed':self.killfeed[-5:]}
