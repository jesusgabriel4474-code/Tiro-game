import asyncio
from server.main import main
asyncio.run(main())
