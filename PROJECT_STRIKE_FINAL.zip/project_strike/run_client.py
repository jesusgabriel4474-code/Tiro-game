from client.game import main
main()
