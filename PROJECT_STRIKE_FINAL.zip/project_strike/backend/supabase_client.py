import os
from supabase import create_client
class StrikeBackend:
 def __init__(self):
  url=os.getenv('SUPABASE_URL'); key=os.getenv('SUPABASE_PUBLISHABLE_KEY')
  self.client=create_client(url,key) if url and key else None
 def ready(self): return self.client is not None
 def save_settings(self,user_id,sensitivity,aim_sensitivity,fov,graphics_quality):
  if not self.client:return None
  return self.client.table('player_settings').upsert({'user_id':user_id,'sensitivity':sensitivity,'aim_sensitivity':aim_sensitivity,'fov':fov,'graphics_quality':graphics_quality}).execute()
 def load_settings(self,user_id):
  if not self.client:return None
  return self.client.table('player_settings').select('*').eq('user_id',user_id).maybe_single().execute()
 def profile(self,user_id):
  if not self.client:return None
  return self.client.table('profiles').select('*').eq('id',user_id).maybe_single().execute()
 def ranking(self,limit=50):
  if not self.client:return []
  return self.client.table('ranked_stats').select('*').order('rating',desc=True).limit(limit).execute().data
