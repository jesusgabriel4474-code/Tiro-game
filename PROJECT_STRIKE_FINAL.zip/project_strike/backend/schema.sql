-- Schema principal usado pelo PROJECT: STRIKE.
-- Execute no Supabase se estiver usando outro projeto.
-- Todas as tabelas expostas ficam com RLS.

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text unique not null,
 display_name text not null default 'Player',
 avatar_url text,
 peer_id text,
 is_online boolean not null default false,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.player_settings (
 user_id uuid primary key references auth.users(id) on delete cascade,
 sensitivity integer not null default 100 check(sensitivity between 1 and 200),
 aim_sensitivity integer not null default 100 check(aim_sensitivity between 1 and 200),
 fov integer not null default 80 check(fov between 60 and 120),
 graphics_quality integer not null default 3 check(graphics_quality between 1 and 4),
 updated_at timestamptz not null default now()
);
create table if not exists public.ranked_stats (
 user_id uuid primary key references auth.users(id) on delete cascade,
 rating integer not null default 1000, rank text not null default 'Bronze', wins integer not null default 0,
 kills integer not null default 0, matches integer not null default 0, updated_at timestamptz not null default now()
);
create table if not exists public.friend_requests (
 id uuid primary key default gen_random_uuid(), sender_id uuid not null references auth.users(id) on delete cascade,
 receiver_id uuid not null references auth.users(id) on delete cascade,
 status text not null default 'pending' check(status in ('pending','accepted','declined')),
 created_at timestamptz not null default now(), unique(sender_id,receiver_id)
);
create table if not exists public.parties (
 id uuid primary key default gen_random_uuid(), leader_id uuid not null references auth.users(id) on delete cascade,
 mode text not null default 'solo' check(mode in ('solo','duo','squad')),
 status text not null default 'open' check(status in ('open','queued','in_match','closed')), created_at timestamptz not null default now()
);
create table if not exists public.party_members (
 party_id uuid references public.parties(id) on delete cascade, user_id uuid references auth.users(id) on delete cascade,
 slot integer not null default 1, ready boolean not null default false, joined_at timestamptz not null default now(),
 primary key(party_id,user_id), unique(party_id,slot)
);
create table if not exists public.matches (
 id uuid primary key default gen_random_uuid(), mode text not null check(mode in ('solo','duo','squad')),
 status text not null default 'waiting' check(status in ('waiting','active','finished')),
 map_name text not null default 'Eclipse Valley', started_at timestamptz, ended_at timestamptz,
 winner_user_id uuid, created_at timestamptz not null default now()
);
create table if not exists public.match_players (
 match_id uuid references public.matches(id) on delete cascade, player_id uuid references auth.users(id) on delete cascade,
 party_id uuid, placement integer, kills integer not null default 0, damage integer not null default 0,
 alive boolean not null default true, joined_at timestamptz not null default now(), primary key(match_id,player_id)
);
create table if not exists public.game_weapons (
 id text primary key, name text not null, category text not null, damage numeric not null, fire_rate numeric not null,
 magazine integer not null, reload_time numeric not null, range numeric not null, headshot_multiplier numeric not null default 1.5, ammo_type text not null
);
create table if not exists public.loot_items (
 id uuid primary key default gen_random_uuid(), match_id uuid references public.matches(id) on delete cascade,
 item_type text not null, item_id text not null, x numeric not null, y numeric not null, z numeric not null,
 taken boolean not null default false, taken_by uuid references auth.users(id), created_at timestamptz not null default now()
);
create table if not exists public.match_events (
 id bigint generated always as identity primary key, match_id uuid references public.matches(id) on delete cascade,
 player_id uuid references auth.users(id), event_type text not null, payload jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
create table if not exists public.player_loadouts (
 user_id uuid primary key references auth.users(id) on delete cascade,
 slot1 text, slot2 text, slot3 text, slot4 text, slot5 text, slot6 text, updated_at timestamptz not null default now()
);
create table if not exists public.friendships (
 user_id uuid references auth.users(id) on delete cascade, friend_id uuid references auth.users(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(user_id,friend_id), check(user_id<>friend_id)
);

insert into public.game_weapons(id,name,category,damage,fire_rate,magazine,reload_time,range,headshot_multiplier,ammo_type) values
('AR-01','Vanguard AR','assault_rifle',22,.105,30,2.1,180,1.5,'5.56'),
('SMG-01','Pulse SMG','smg',15,.065,35,1.8,90,1.4,'9mm'),
('SHOT-01','Breaker 12','shotgun',9,.75,6,2.4,38,1.25,'12g'),
('DMR-01','Sentinel DMR','dmr',42,.35,12,2.3,260,1.65,'7.62'),
('SNIPER-01','Longshot','sniper',90,1.3,5,2.8,500,2,'7.62')
on conflict(id) do update set name=excluded.name,damage=excluded.damage,fire_rate=excluded.fire_rate,magazine=excluded.magazine,reload_time=excluded.reload_time,range=excluded.range,headshot_multiplier=excluded.headshot_multiplier;

alter table public.profiles enable row level security;
alter table public.player_settings enable row level security;
alter table public.ranked_stats enable row level security;
alter table public.friend_requests enable row level security;
alter table public.parties enable row level security;
alter table public.party_members enable row level security;
alter table public.matches enable row level security;
alter table public.match_players enable row level security;
alter table public.game_weapons enable row level security;
alter table public.loot_items enable row level security;
alter table public.match_events enable row level security;
alter table public.player_loadouts enable row level security;
alter table public.friendships enable row level security;
