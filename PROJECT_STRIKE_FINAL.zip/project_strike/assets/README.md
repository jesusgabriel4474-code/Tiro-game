Coloque aqui modelos próprios `.glb`/`.bam` e sons. A versão procedural já é jogável e não depende de downloads externos.
