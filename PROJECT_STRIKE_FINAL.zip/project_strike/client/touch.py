from direct.gui.DirectGui import DirectButton,DirectFrame
from panda3d.core import TextNode
class TouchController:
 def __init__(self,app,net,weapon):
  self.app=app; self.net=net; self.weapon=weapon; self.enabled=True; self.fire=False
  self.panel=DirectFrame(frameColor=(0,0,0,0),frameSize=(-1.35,1.35,-.75,.75),pos=(0,0,0))
  self.btn('FIRE',(.78,0,-.42),self.do_fire,.09); self.btn('AIM',(.58,0,-.28),self.do_aim,.055); self.btn('JUMP',(.83,0,-.12),lambda:app.accept('space'),.045); self.btn('R',(.48,0,.15),lambda:self.weapon.reload(),.045)
  for i,w in enumerate(['AR-01','SMG-01','SHOT-01','DMR-01','SNIPER-01']): self.btn(str(i+1),(-.72+i*.12,-0.02,-.58),lambda w=w:self.weapon.select(w),.035)
 def btn(self,text,pos,cmd,scale):
  DirectButton(parent=self.panel,text=text,scale=scale,pos=pos,frameColor=(.05,.07,.1,.72),text_fg=(1,1,1,1),command=cmd)
 def do_fire(self): self.weapon.shoot(self.app.camera_controller.yaw,self.app.camera_controller.pitch)
 def do_aim(self): self.app.camera_controller.setaim(True)
