from panda3d.core import NodePath, CardMaker
from direct.task import Task
import math
class PlayerController:
 def __init__(self,app,net):
  self.app=app; self.net=net; self.node=app.render.attachNewNode('LocalPlayer'); self.speed=10; self.sprint=False
  body=app.loader.loadModel('models/box'); body.reparentTo(self.node); body.setScale(.65,.45,1.2); body.setPos(0,0,1.2)
  self.keys={k:False for k in ['w','a','s','d','shift','ctrl']}
  for k in self.keys: app.accept(k,self.setkey,[k,True]); app.accept(k+'-up',self.setkey,[k,False])
  app.taskMgr.add(self.update,'player_update')
 def setkey(self,k,v): self.keys[k]=v
 def update(self,task):
  dt=min(task.dt,.05); cam=self.app.camera_controller
  f=(1 if self.keys['w'] else 0)-(1 if self.keys['s'] else 0); r=(1 if self.keys['d'] else 0)-(1 if self.keys['a'] else 0)
  l=math.hypot(f,r) or 1; f/=l; r/=l; yaw=math.radians(cam.yaw)
  dx=(math.cos(yaw)*f-math.sin(yaw)*r)*self.speed*dt; dy=(math.sin(yaw)*f+math.cos(yaw)*r)*self.speed*dt
  if self.keys['shift']: dx*=1.55; dy*=1.55
  self.node.setX(self.node.getX()+dx); self.node.setY(self.node.getY()+dy)
  self.net.send({'type':'move','x':self.node.getX(),'y':self.node.getY(),'yaw':cam.yaw,'pitch':cam.pitch,'sprint':self.keys['shift']})
  return Task.cont
