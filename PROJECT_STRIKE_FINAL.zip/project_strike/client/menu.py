"""Optional lobby model used by a future visual menu. Network protocol is already implemented in server.main."""
class LobbyState:
 def __init__(self): self.mode='solo'; self.members=[]; self.ready=False; self.friends=[]; self.ranked=False
 def set_mode(self,mode): self.mode=mode if mode in ('solo','duo','squad') else 'solo'
