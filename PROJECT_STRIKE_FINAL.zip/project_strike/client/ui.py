from direct.gui.DirectGui import DirectFrame,DirectLabel,DirectButton,DirectEntry
from panda3d.core import TextNode
class GameUI:
 def __init__(self,app,net,weapons):
  self.app=app; self.net=net; self.weapons=weapons; self.hp=100; self.armor=0; self.ammo=30; self.reserve=120; self.kills=0; self.feed=[]
  self.root=DirectFrame(frameColor=(.025,.03,.045,.88),frameSize=(-.5,.5,-.16,.16),pos=(0,-.02,-.72)); self.root.setTransparency(1)
  self.status=DirectLabel(parent=self.root,text='HP 100   ARMOR 0',scale=.045,pos=(-.43,0,.055),text_align=TextNode.ALeft,text_fg=(.9,.95,1,1))
  self.ammoLabel=DirectLabel(parent=self.root,text='30 / 120',scale=.055,pos=(.32,0,.055),text_fg=(1,1,1,1))
  self.cross=DirectLabel(text='+',scale=.045,pos=(0,0,0),text_fg=(1,1,1,1))
  self.info=DirectLabel(text='SOLO • ECLIPSE VALLEY',scale=.035,pos=(-1.25,0,.88),text_fg=(.65,.8,1,1))
  self.zone=DirectLabel(text='ZONE 240m',scale=.035,pos=(.7,0,.88),text_fg=(1,.7,.25,1))
  self.feedlabel=DirectLabel(text='',scale=.032,pos=(.62,0,.65),text_align=TextNode.ARight,text_fg=(1,.85,.85,1))
  self.slot_buttons=[]
  for i in range(5):
   b=DirectButton(text=str(i+1),scale=.045,frameSize=(-.7,.7,-.7,.7),pos=(-.62+i*.09,0,-.68),command=self.slot,args=[i]); self.slot_buttons.append(b)
 def slot(self,i):
  if i<len(self.weapons): self.weapons.select(list(self.weapons.WEAPONS.keys())[i] if hasattr(self.weapons,'WEAPONS') else ['AR-01','SMG-01','SHOT-01','DMR-01','SNIPER-01'][i])
 def update(self,p,zone,feed):
  self.status['text']=f"HP {int(p.get('hp',100))}   ARMOR {int(p.get('armor',0))}   KILLS {p.get('kills',0)}"
  self.ammoLabel['text']=f"{p.get('ammo',0)} / {p.get('reserve',0)}"
  self.zone['text']=f"ZONE {int(zone.get('radius',0))}m"
  self.feedlabel['text']='\n'.join(f"{x.get('killer')}  ›  {x.get('victim')}" for x in feed[-4:])
