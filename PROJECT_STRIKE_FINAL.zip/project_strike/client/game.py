from direct.showbase.ShowBase import ShowBase
from panda3d.core import WindowProperties,TextNode
from direct.task import Task
import os,uuid
from .net import NetworkClient
from .world import WorldBuilder
from .player import PlayerController
from .camera import ThirdPersonCamera
from .weapons import WeaponController,WEAPONS
from .ui import GameUI
from .touch import TouchController
class Game(ShowBase):
 def __init__(self):
  ShowBase.__init__(self); props=WindowProperties(); props.setTitle('PROJECT: STRIKE'); props.setSize(1280,720); self.win.requestProperties(props)
  self.net=NetworkClient(); self.net.start(); self.player_id=str(uuid.uuid4()); self.world=WorldBuilder(self); self.local=PlayerController(self,self.net); self.camera_controller=ThirdPersonCamera(self,self.local.node)
  self.weapon=WeaponController(self.net); self.weapon.WEAPONS=WEAPONS
  self.ui=GameUI(self,self.net,list(WEAPONS.keys())); self.touch=TouchController(self,self.net,self.weapon)
  self.accept('mouse1',self.fire); self.accept('r',self.weapon.reload)
  for i,w in enumerate(WEAPONS): self.accept(str(i+1),self.weapon.select,[w])
  self.accept('escape',self.userExit); self.accept('m',self.toggle_menu)
  self.net.send({'type':'join','player_id':self.player_id,'mode':'solo'}); self.last_state=None; self.taskMgr.add(self.network_update,'network_update')
 def fire(self): self.weapon.shoot(self.camera_controller.yaw,self.camera_controller.pitch)
 def toggle_menu(self): pass
 def network_update(self,task):
  for m in self.net.poll():
   if m.get('type')=='state':
    s=m['state']; self.last_state=s; self.world.sync_loot(s.get('loot',[]))
    me=next((p for p in s['players'] if p['id']==self.player_id),None)
    if me: self.ui.update(me,s['zone'],s.get('killfeed',[]))
   elif m.get('type')=='elimination': pass
   elif m.get('type')=='match_end': self.ui.info['text']='MATCH FINALIZADA'
  return Task.cont

def main(): Game().run()
