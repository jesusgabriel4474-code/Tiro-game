from panda3d.core import AmbientLight,DirectionalLight,Vec4,Vec3,TransparencyAttrib
from panda3d.core import CollisionTraverser,CollisionNode,CollisionSphere,CollisionHandlerQueue
class WorldBuilder:
 def __init__(self,app):
  self.app=app; self.root=app.render.attachNewNode('World'); self.loot_nodes={}; self._build()
 def _build(self):
  cm=self.app.loader.loadModel('models/plane'); cm.reparentTo(self.root); cm.setScale(250); cm.setColor(.10,.13,.16,1)
  for i,(x,y,s) in enumerate([(-45,20,14),(30,35,18),(70,-20,12),(-75,-45,20),(0,-70,16),(100,80,22),(-110,70,16),(45,-100,24)]):
   b=self.app.loader.loadModel('models/box'); b.reparentTo(self.root); b.setPos(x,y,s*.5); b.setScale(s,s,s); b.setColor(.20,.23,.27,1)
  for i in range(18):
   x=((i*47)%360)-180; y=((i*83)%300)-150
   if abs(x)<30 and abs(y)<30: continue
   b=self.app.loader.loadModel('models/box'); b.reparentTo(self.root); b.setPos(x,y,.5); b.setScale(2.5,2.5,1); b.setColor(.25,.29,.32,1)
  a=AmbientLight('ambient'); a.setColor(Vec4(.55,.55,.62,1)); self.root.setLight(self.root.attachNewNode(a))
  d=DirectionalLight('sun'); d.setColor(Vec4(.85,.85,.8,1)); dn=self.root.attachNewNode(d); dn.setHpr(-35,-55,0); self.root.setLight(dn)
 def sync_loot(self,items):
  seen=set()
  for it in items:
   seen.add(it['id'])
   if it['id'] not in self.loot_nodes:
    n=self.app.loader.loadModel('models/box'); n.reparentTo(self.root); n.setScale(.45); n.setPos(it['x'],it['y'],it['z']+.35)
    if it['kind']=='weapon': n.setColor(.85,.55,.12,1)
    elif it['kind']=='armor': n.setColor(.1,.45,.95,1)
    elif it['kind']=='medkit': n.setColor(.2,.85,.35,1)
    else: n.setColor(.7,.7,.2,1)
    self.loot_nodes[it['id']]=n
  for lid in list(self.loot_nodes):
   if lid not in seen: self.loot_nodes[lid].removeNode(); del self.loot_nodes[lid]
