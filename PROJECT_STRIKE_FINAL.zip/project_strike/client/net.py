import asyncio, json, threading, queue
from websockets.sync.client import connect
class NetworkClient:
    def __init__(self,url='ws://127.0.0.1:8765'):
        self.url=url; self.ws=None; self.inbox=queue.Queue(); self.connected=False
    def start(self): threading.Thread(target=self._run,daemon=True).start()
    def _run(self):
        try:
            self.ws=connect(self.url); self.connected=True
            while True:
                raw=self.ws.recv()
                if raw: self.inbox.put(json.loads(raw))
        except: self.connected=False
    def send(self,msg):
        try:
            if self.ws: self.ws.send(json.dumps(msg,separators=(',',':')))
        except: pass
    def poll(self):
        out=[]
        while True:
            try: out.append(self.inbox.get_nowait())
            except queue.Empty: return out
