from panda3d.core import Point3
class ThirdPersonCamera:
 def __init__(self,app,target):
  self.app=app; self.target=target; self.yaw=0; self.pitch=-10; self.sensitivity=100; self.aim=False; self.drag=False
  app.disableMouse(); app.taskMgr.add(self.update,'camera_update'); app.accept('mouse3',self.setaim,[True]); app.accept('mouse3-up',self.setaim,[False])
 def setaim(self,v): self.aim=v
 def update(self,task):
  # Relative mouse camera. Re-centers cursor when possible.
  if self.app.mouseWatcherNode.hasMouse():
   m=self.app.mouseWatcherNode.getMouse(); self.yaw-=m.getX()*self.sensitivity*.55; self.pitch=max(-65,min(30,self.pitch+m.getY()*self.sensitivity*.35));
   self.app.win.movePointer(0,self.app.win.getXSize()//2,self.app.win.getYSize()//2)
  d=6 if not self.aim else 3.4; h=2.3 if not self.aim else 1.8
  import math
  y=math.radians(self.yaw); p=math.radians(self.pitch)
  pos=self.target.getPos(); x=pos.x-math.sin(y)*d; yy=pos.y-math.cos(y)*d; z=pos.z+h+math.sin(p)*d*.4
  self.app.camera.setPos(x,yy,z); self.app.camera.lookAt(pos.x,pos.y,pos.z+1.2)
  return task.cont
