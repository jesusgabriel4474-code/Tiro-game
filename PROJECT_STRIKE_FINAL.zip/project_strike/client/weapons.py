from dataclasses import dataclass
@dataclass(frozen=True)
class Weapon:
 id:str; name:str; damage:float; fire_rate:float; magazine:int; reload:float; range:float
WEAPONS={
 'AR-01':Weapon('AR-01','Vanguard AR',22,.105,30,2.1,180),
 'SMG-01':Weapon('SMG-01','Pulse SMG',15,.065,35,1.8,90),
 'SHOT-01':Weapon('SHOT-01','Breaker 12',9,.75,6,2.4,38),
 'DMR-01':Weapon('DMR-01','Sentinel DMR',42,.35,12,2.3,260),
 'SNIPER-01':Weapon('SNIPER-01','Longshot',90,1.3,5,2.8,500)}
class WeaponController:
 def __init__(self,net): self.net=net; self.current='AR-01'
 def select(self,wid): self.current=wid; self.net.send({'type':'weapon','weapon':wid})
 def shoot(self,yaw,pitch): self.net.send({'type':'shoot','yaw':yaw,'pitch':pitch})
 def reload(self): self.net.send({'type':'reload'})
