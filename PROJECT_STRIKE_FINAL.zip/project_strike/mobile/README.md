# Android / mobile

O servidor é o mesmo do PC. A camada `client/touch.py` fornece botões virtuais e a lógica não depende de teclado para as ações principais.

## Empacotamento
O Panda3D tem suporte a Android, mas o pacote final precisa ser montado com uma cadeia de build compatível com a versão do Python/Panda3D instalada. Esta pasta mantém o projeto separado para isso em vez de prometer um APK pré-compilado que não foi testado no aparelho.

Fluxo recomendado:
1. Instale Python/Buildozer em um ambiente de desenvolvimento.
2. Configure o target Android com Python compatível com a release do Panda3D escolhida.
3. Inclua `panda3d`, `panda3d-gles`/componentes Android apropriados e os módulos do projeto.
4. Aponte o cliente para o IP/hostname público do servidor WebSocket.
5. Gere debug APK e teste toque, câmera e desempenho antes de release.

Para jogar no celular imediatamente sem empacotar, use o mesmo código em um ambiente Android que consiga instalar Panda3D/Python. O servidor pode ficar em outro PC/VPS.
