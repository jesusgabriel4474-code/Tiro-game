# PROJECT: STRIKE — Battle Royale Python

Projeto original de battle royale 3D em Python, com cliente Panda3D, servidor WebSocket autoritativo e persistência opcional no Supabase.

## O que esta versão entrega
- 3D em terceira pessoa no PC.
- Mouse para câmera, WASD, sprint, pulo, agachar, mira, tiro, recarga e troca de armas.
- Controles touch/virtual para a camada de cliente.
- Servidor autoritativo para movimento, cadência, munição, dano, eliminações e loot.
- 5 armas com dano, recoil/spread lógico, munição e recarga.
- Armas e consumíveis espalhados pelo mapa para coleta.
- Inventário de 6 slots.
- Zona segura que diminui e causa dano fora dela.
- Solo/Duo/Squad e sistema de party/matchmaking no servidor.
- HUD de HP/armadura/munição, kill feed, minimapa simples, zona e colocação.
- Ranking e estatísticas preparados para Supabase.
- Tabelas/RLS do Supabase incluídas em `backend/schema.sql`.
- Cliente não contém service-role/secret key.

## Rodar no PC
1. Python 3.11+ recomendado.
2. `pip install -r requirements.txt`
3. Copie `config.example.json` para `config.json` e preencha apenas a publishable key se quiser Supabase no cliente.
4. Terminal 1: `python run_server.py`
5. Terminal 2: `python run_client.py`
6. Abra vários clientes para testar multiplayer local.

## Supabase
A base já foi preparada no projeto conectado ao ChatGPT. Para outro projeto, use `backend/schema.sql` e uma publishable key. Nunca coloque uma `sb_secret_...` ou `service_role` no cliente.

## Android/mobile
`mobile/README.md` explica a rota de empacotamento. O gameplay foi separado do protocolo para permitir o mesmo servidor em PC e mobile. A camada touch está em `client/touch.py` e o cliente usa eventos de mouse/touch para controles virtuais.

## Limite importante
Os modelos 3D desta entrega são gerados proceduralmente para manter o projeto leve e distribuível. Eles são jogáveis, mas podem ser substituídos por modelos GLB/OBJ próprios em `assets/` sem alterar o protocolo de rede.
