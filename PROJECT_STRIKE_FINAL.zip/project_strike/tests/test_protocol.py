import json
from server.game_state import PlayerState,Room

def test_player_snapshot():
 p=PlayerState('x'); s=p.snapshot(); assert s['id']=='x' and s['hp']==100

def test_room():
 r=Room('a','squad'); assert r.max_players==4; assert len(r.loot)>=50
